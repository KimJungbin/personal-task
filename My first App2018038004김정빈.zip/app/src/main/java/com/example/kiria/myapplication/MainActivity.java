package com.example.kiria.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Toast;

/* **********************************************
 * 프로그램명 : activity-main.xml
 * 작성자 : 2018038004 김정빈
 * 작성일 : 2020.04.12
 *프로그램 설명 : 많이 그럴듯해보이는 어플리케이션 프로그램
 ************************************************/

public class MainActivity extends AppCompatActivity {
    Button button1;
    Button button2;
    EditText editText1;
    String value;
    RadioGroup rg;
    ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button1 = (Button)findViewById(R.id.button1);
        button2 = (Button)findViewById(R.id.button2);
        editText1 = (EditText)findViewById(R.id.editText);
        rg = (RadioGroup)findViewById(R.id.radioGroup);
        img = (ImageView)findViewById(R.id.imageView);

        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i==R.id.radioButton1){
                    img.setImageResource(R.drawable.pie);
                }else if(i==R.id.radioButton2){
                    img.setImageResource(R.drawable.oreo);
                }
            }
        });
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value = editText1.getText().toString();
                Toast.makeText(getApplicationContext(), value , Toast.LENGTH_SHORT).show();
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value = editText1.getText().toString();
                Intent intent = new Intent (Intent.ACTION_VIEW, Uri.parse(value));
                startActivity(intent);
            }
        });
    }
}

