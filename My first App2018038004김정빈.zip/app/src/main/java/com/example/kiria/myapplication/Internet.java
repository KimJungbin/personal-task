package com.example.kiria.myapplication;

class Internet {
}
